const loginValidation = require("./loginValidation")
const signupValidation = require("./signupValidation")

module.exports = {
  signupValidation,
  loginValidation,
}
