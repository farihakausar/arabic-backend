const { ArtistProfile } = require("../../../models/ArtistProfile");

const appreciationCount = async (req, res) => {};

module.exports = {
  appreciationCount,
};
