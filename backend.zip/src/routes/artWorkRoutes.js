const path = require("path")

const artWorkRoutes = path.join(
  __dirname,
  "..",
  "api",
  "artWork",
)

module.exports = artWorkRoutes
