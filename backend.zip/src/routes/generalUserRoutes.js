const path = require("path")

const generalUserRoutes = path.join(
  __dirname,
  "..",
  "api",
  "generalUser",
)

module.exports = generalUserRoutes
