const path = require("path")

const notificationRoutes = path.join(
  __dirname,
  "..",
  "api",
  "notification",
)

module.exports = notificationRoutes
