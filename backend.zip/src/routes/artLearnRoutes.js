const path = require("path")

const artLearnRoutes = path.join(
  __dirname,
  "..",
  "api",
  "artLearn",
)

module.exports = artLearnRoutes
