const path = require("path")

const artMarketRoutes = path.join(
  __dirname,
  "..",
  "api",
  "artMarket",
)

module.exports = artMarketRoutes
