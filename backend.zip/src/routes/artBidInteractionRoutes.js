const path = require("path")

const artBidInteractionRoutes = path.join(
  __dirname,
  "..",
  "api",
  "artBidInteraction",
)

module.exports = artBidInteractionRoutes
