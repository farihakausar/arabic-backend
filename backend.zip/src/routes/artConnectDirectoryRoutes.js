const path = require("path")

const artConnectDirectoryRoutes = path.join(
  __dirname,
  "..",
  "api",
  "artConnectDirectory",
)

module.exports = artConnectDirectoryRoutes
