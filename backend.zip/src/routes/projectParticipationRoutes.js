const path = require("path")

const projectParticipationRoutes = path.join(
  __dirname,
  "..",
  "api",
  "projectParticipation",
)

module.exports = projectParticipationRoutes
