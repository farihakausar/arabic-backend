const path = require("path")

const userRoutes= path.join(
  __dirname,
  "..",
  "api",
  "user",
)

module.exports = userRoutes
